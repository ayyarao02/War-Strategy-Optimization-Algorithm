%%       Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%% Ayyarao, TummalaS LV, N. S. S. RamaKrishna, Rajvikram Madurai Elavarasam, Nishanth Polumahanthi, M. Rambabu, Gaurav Saini, Baseem Khan, and Bilal Alatas. "War Strategy Optimization Algorithm: A New Effective Metaheuristic Algorithm for Global Optimization." IEEE Access (2022).
%% https://ieeexplore.ieee.org/abstract/document/9718247
%% Code developed by Tummala.S.L.V.Ayyarao
%% Ayyarao, Tummala SLV, and Polamarasetty P. Kumar. "Parameter estimation of solar PV models with a new proposed war strategy optimization algorithm." International Journal of Energy Research (2022).
%% https://onlinelibrary.wiley.com/doi/abs/10.1002/er.7629
clear
clc



fEvals = 30000;    

populationSize=30; % Number of search agents
Max_iteration = 1000;
runs = 10;

for fn = 1:18

    Function_name=strcat('F',num2str(fn)); % Name of the test function 
%     [lb,ub,dim,fobj]=Get_Functions_details(Function_name);
    [lb,ub,dim,fobj]=Get_Functions_Details_Uni(Function_name);
    
%     Function_name=strcat('MF',num2str(fn)); % Name of the test function 
%     [lb,ub,dim,fobj]=Get_Functions_Details_Multi(Function_name);

    % Calling algorithm
    Best_score_T = zeros(1,runs);
    for run=1:runs
        rng('shuffle');
        tic
        Best_score_0 =WSO(populationSize,Max_iteration,lb,ub,dim,fobj);
        toc
        Best_score_T(1,run) = Best_score_0;
        
%         Best_score_0
    end

    %Finding statistics
    Best_score_Best = min(Best_score_T);
    Best_score_Worst = max(Best_score_T);
    Best_score_Median = median(Best_score_T,2);
    Best_Score_Mean = mean(Best_score_T,2);
    Best_Score_std = std(Best_score_T);


    %Printing results
    display(['Fn = ', num2str(fn)]);
    display(['Median, Mean, and Std. are as: ',  ...
         num2str(Best_score_Median),'  ', num2str(Best_Score_Mean),'  ', num2str(Best_Score_std)]);

end
